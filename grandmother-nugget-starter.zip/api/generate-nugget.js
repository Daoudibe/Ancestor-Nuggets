import { Configuration, OpenAIApi } from "openai";

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).end("Method Not Allowed");
  }

  const { name, country, year } = req.body;

  if (!name || !country || !year) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  const prompt = `
You are a professional historian and cultural researcher.

A user has entered this family data:
- Relationship: your mother's mother
- Name: ${name}
- Country of birth: ${country}
- Year of birth: ${year}

Generate ONE vivid, emotionally engaging, historically accurate nugget (1–3 sentences) about what life was like in ${country} in ${year}, when ${name} was born.

Use the name and the relationship naturally in the text (e.g., “When your grandmother ${name} was born…”).  
Focus on:
- A meaningful local or global event from that time
- Cultural or social context (how people lived, political change, etc.)
- Avoid general facts or lists — write like you're painting a snapshot from that time
- Mention hobbies or music only if they were culturally significant

Make the nugget sound warm, curious, and grounded in real history.
`;

  try {
    const completion = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
    });

    const nugget = completion.data.choices[0].message.content.trim();
    res.status(200).json({ nugget });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to generate nugget" });
  }
}
